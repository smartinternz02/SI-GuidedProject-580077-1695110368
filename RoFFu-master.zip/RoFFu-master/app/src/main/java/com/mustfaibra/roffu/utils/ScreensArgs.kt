package com.mustfaibra.roffu.utils

object ScreensArgs