package com.mustfaibra.roffu.utils

object Url {
    const val SIGNIN_URL = ""
    const val SIGNUP_URL = ""
}