package com.mustfaibra.roffu.sealed

sealed class Orientation {
    object Vertical : Orientation()
    object Horizontal : Orientation()
}